﻿Public Class frmUser

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click

        If txtpassword.Text = "" Then
            MsgBox("Password must be filled up.", MsgBoxStyle.Exclamation)
            Return
        End If
        If txtcpaswrd.Text = "" Then
            MsgBox("Password must be filled up.", MsgBoxStyle.Exclamation)
            Return
        End If
        If btnsave.Text = "Save" Then
            If txtpassword.Text = txtcpaswrd.Text Then
                issucess = janobeinsert("INSERT INTO `tblemployee` (`EMPID`, `EMPNAME`, `EMPCONTACT`, `EMPPOSITION`, `USERNAME`, `PASSWORD`, `SECRETQUESTION`, `SECRETANSWER`) " &
                            " VALUES (NULL, '" & txtname.Text & "', '" & txtcontact.Text & "', '" & txtposition.Text & "', '" & txtusername.Text & "', '" & txtpassword.Text & "', '" & cmbSecretQuestion.Text & "', '" & txtSecretAnswer.Text & "')")
                If issucess = True Then
                    MsgBox("Employee record has been saved!")
                Else
                    MsgBox("No record has been saved!")
                End If
            Else
                MsgBox("Password not match!")
            End If
        Else
            If txtpassword.Text = txtcpaswrd.Text Then
                issucess = janoupdate("UPDATE `tblemployee` SET `EMPNAME`='" & txtname.Text & "', `EMPCONTACT`='" & txtcontact.Text & "', `EMPPOSITION`='" & txtposition.Text & "', `USERNAME`='" & txtusername.Text & "', `PASSWORD`='" & txtpassword.Text & "', `SecretQuestion`='" & cmbSecretQuestion.Text & "', `SecretAnswer`='" & txtSecretAnswer.Text & "' where EMPID=" & Val(lblid.Text) & "")
                If issucess = True Then
                    MsgBox("Employee record has been Updated!")
                Else
                    MsgBox("No record has been Updated!")
                End If
            Else
                MsgBox("Password not match!")
            End If
        End If
        Call btnnew_Click(sender, e)
    End Sub

    Private Sub frmuser_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        janobefindthis("SELECT EMPID, EMPNAME, EMPCONTACT, EMPPOSITION, USERNAME, SECRETQUESTION FROM tblemployee")
        LoadData(DataGridView1, "employee")
    End Sub

    Private Sub btnnew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnew.Click
        janobefindthis("SELECT EMPID, EMPNAME, EMPCONTACT, EMPPOSITION, USERNAME, SECRETQUESTION FROM tblemployee")
        LoadData(DataGridView1, "employee")
        ClearAll(GroupBox1, "employee")
        txtposition.Text = "Select"
        btnsave.Text = "Save"
    End Sub

    Private Sub DataGridView1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.Click
        Try
            lblid.Text = DataGridView1.CurrentRow.Cells(0).Value
            txtname.Text = DataGridView1.CurrentRow.Cells(1).Value
            txtcontact.Text = DataGridView1.CurrentRow.Cells(2).Value
            txtposition.Text = DataGridView1.CurrentRow.Cells(3).Value
            txtusername.Text = DataGridView1.CurrentRow.Cells(4).Value
            cmbSecretQuestion.Text = DataGridView1.CurrentRow.Cells(5).Value
            btnsave.Text = "Update"
        Catch ex As Exception
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            If txtname.Text.Equals(String.Empty) Then
                MsgBox("This action cannot be performed.", MsgBoxStyle.Information)
            Else
                Dim question As String
                question = MsgBox("Are you sure you want to delete ?", MsgBoxStyle.Exclamation + MsgBoxStyle.YesNo, "ATTENTION !")
                If question = vbYes Then
                    DeleteUser()
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Public Sub DeleteUser()
        Try
            janobedelete("DELETE FROM tblemployee WHERE EMPID = '" & DataGridView1.CurrentRow.Cells(0).Value & "'")
            LoadData(DataGridView1, "employee")
            load_emp()
        Catch ex As Exception
        End Try
    End Sub
    Public Sub load_emp()
        janobefindthis("SELECT EMPID, EMPNAME, EMPCONTACT, EMPPOSITION, USERNAME, SECRETQUESTION FROM tblemployee")
        LoadData(DataGridView1, "employee")
        ClearAll(GroupBox1, "employee")
    End Sub

    Private Sub txtcontact_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtcontact.KeyPress
        If Char.IsDigit(e.KeyChar) = False And Char.IsControl(e.KeyChar) = False Then
            e.Handled = True
        End If
    End Sub
End Class