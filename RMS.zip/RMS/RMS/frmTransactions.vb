﻿Imports System.Drawing.Printing

Public Class frmTransactions
    Private mRow As Integer = 0
    Private newpage As Boolean = True
    Dim g, mg As Graphics
    Dim bmp As Bitmap
    Private Sub frmTransactions_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        load_transac()
        For Each ctrl As Control In Controls
            If ctrl.GetType Is GetType(DateTimePicker) Then
                ctrl.Text = Now
            End If
        Next
    End Sub
    Public Sub load_transac()
        sql = "SELECT INVOICENO, ORNO, TRANSDATE, TRANSTIME, AMOUNTSALE, DISCOUNT, TAX, TOTALDUE, AMOUNTRECIEVED, AMOUNTCHANGE, CASHIER FROM tbltransaction"
        reloadDgv(sql, DataGridView1)
        clearcontrol(pnlDateFilter)
    End Sub
    Public Sub clearcontrol(ByVal obj As Object)

        For Each ctrl As Control In obj.Controls
            If ctrl.GetType Is GetType(DateTimePicker) Then
                ctrl.Text = Now
            End If
        Next
    End Sub
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Try
            sql = "SELECT * FROM tbltransaction WHERE TRANSDATE BETWEEN '" & dtpFROM.Text & "' AND '" & dtpTO.Text & "'"
            reloadDgv(sql, DataGridView1)
        Catch ex As Exception
            MessageBox.Show(ex.Message & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        Try
            mRow = 0
            newpage = True
            Dim xCustomSize As New PaperSize("Legal", 850, 1600)
            PrintDocument1.DefaultPageSettings.PaperSize = xCustomSize
            PrintDocument1.DefaultPageSettings.Landscape = True
            PrintPreviewDialog1.PrintPreviewControl.StartPage = 0
            PrintPreviewDialog1.PrintPreviewControl.Zoom = 1.0
            PrintPreviewDialog1.Document = PrintDocument1
            PrintPreviewDialog1.ShowDialog()
        Catch ex As Exception
            MessageBox.Show(ex.Message & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Try
            Dim fmt As StringFormat = New StringFormat(StringFormatFlags.LineLimit)
            fmt.LineAlignment = StringAlignment.Center
            fmt.Trimming = StringTrimming.EllipsisCharacter
            Dim y As Int32 = e.MarginBounds.Top
            Dim rc As Rectangle
            Dim x As Int32
            Dim h As Int32 = 0
            Dim row As DataGridViewRow

            If newpage Then
                row = DataGridView1.Rows(mRow)
                x = e.MarginBounds.Left
                For Each cell As DataGridViewCell In row.Cells
                    If cell.Visible Then
                        rc = New Rectangle(x, y, cell.Size.Width, cell.Size.Height)

                        e.Graphics.FillRectangle(Brushes.LightGray, rc)
                        e.Graphics.DrawRectangle(Pens.Black, rc)

                        Select Case DataGridView1.Columns(cell.ColumnIndex).DefaultCellStyle.Alignment
                            Case DataGridViewContentAlignment.BottomRight,
                                 DataGridViewContentAlignment.MiddleRight
                                fmt.Alignment = StringAlignment.Far
                                rc.Offset(-1, 0)
                            Case DataGridViewContentAlignment.BottomCenter,
                                DataGridViewContentAlignment.MiddleCenter
                                fmt.Alignment = StringAlignment.Center
                            Case Else
                                fmt.Alignment = StringAlignment.Near
                                rc.Offset(2, 0)
                        End Select

                        e.Graphics.DrawString(DataGridView1.Columns(cell.ColumnIndex).HeaderText, DataGridView1.Font, Brushes.Black, rc, fmt)
                        x += rc.Width
                        h = Math.Max(h, rc.Height)
                    End If
                Next
                y += h

            End If
            newpage = False

            Dim thisNDX As Int32
            For thisNDX = mRow To DataGridView1.RowCount - 1

                If DataGridView1.Rows(thisNDX).IsNewRow Then Exit For

                row = DataGridView1.Rows(thisNDX)
                x = e.MarginBounds.Left
                h = 0

                x = e.MarginBounds.Left

                For Each cell As DataGridViewCell In row.Cells
                    If cell.Visible Then
                        rc = New Rectangle(x, y, cell.Size.Width, cell.Size.Height)
                        e.Graphics.DrawRectangle(Pens.Black, rc)

                        Select Case DataGridView1.Columns(cell.ColumnIndex).DefaultCellStyle.Alignment
                            Case DataGridViewContentAlignment.BottomRight,
                                 DataGridViewContentAlignment.MiddleRight
                                fmt.Alignment = StringAlignment.Far
                                rc.Offset(-1, 0)
                            Case DataGridViewContentAlignment.BottomCenter,
                                DataGridViewContentAlignment.MiddleCenter
                                fmt.Alignment = StringAlignment.Center
                            Case Else
                                fmt.Alignment = StringAlignment.Near
                                rc.Offset(2, 0)
                        End Select

                        e.Graphics.DrawString(cell.FormattedValue.ToString(),
                                              DataGridView1.Font, Brushes.Black, rc, fmt)

                        x += rc.Width
                        h = Math.Max(h, rc.Height)
                    End If
                Next
                y += h
                mRow = thisNDX + 1

                If y + h > e.MarginBounds.Bottom Then
                    e.HasMorePages = True
                    newpage = True
                    Return
                End If
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message & vbCrLf & ex.StackTrace)
        End Try
    End Sub
End Class