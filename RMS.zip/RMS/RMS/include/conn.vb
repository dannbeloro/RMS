﻿Imports MySql.Data.MySqlClient
Module Conn
    Public Function mysqldb() As MySqlConnection
        Return New MySqlConnection("server=localhost;userid=root;password=test123;database=dbpos")
    End Function
    Public con As MySqlConnection = mysqldb()
End Module
