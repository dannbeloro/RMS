﻿Imports MySql.Data.MySqlClient
Module user
    Public con As MySqlConnection = mysqldb()
    Public Sub LogIn(ByVal username As Object, ByVal password As Object)
        Try
            con.Open()
            Dim query As String
            query = "SELECT EMPPOSITION FROM tblemployee where BINARY Username= '" & username & "' and BINARY Password = '" & password & "' "
            cmd = New MySqlCommand(query, con)
            dReader = cmd.ExecuteReader
            If dReader.HasRows() Then
                dReader.Read()
                If dReader("EMPPOSITION") = "Administrator" Then
                    Visible_Admin(True)
                    LoginForm1.Hide()
                Else
                    Visible_Cashier(True)
                    LoginForm1.Hide()
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        con.Close()
    End Sub
End Module
