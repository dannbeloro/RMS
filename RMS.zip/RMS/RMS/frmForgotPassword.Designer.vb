﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmForgotPassword
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtSecretAnswer = New System.Windows.Forms.TextBox()
        Me.cmbSecretQuestion = New System.Windows.Forms.ComboBox()
        Me.chckboxSecretAnswer = New System.Windows.Forms.CheckBox()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.lblSecretAnswer = New System.Windows.Forms.Label()
        Me.lblSecretQuestion = New System.Windows.Forms.Label()
        Me.lblUsername = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtSecretAnswer
        '
        Me.txtSecretAnswer.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSecretAnswer.Location = New System.Drawing.Point(123, 91)
        Me.txtSecretAnswer.MaxLength = 40
        Me.txtSecretAnswer.Name = "txtSecretAnswer"
        Me.txtSecretAnswer.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtSecretAnswer.Size = New System.Drawing.Size(217, 20)
        Me.txtSecretAnswer.TabIndex = 18
        '
        'cmbSecretQuestion
        '
        Me.cmbSecretQuestion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbSecretQuestion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbSecretQuestion.FormattingEnabled = True
        Me.cmbSecretQuestion.Items.AddRange(New Object() {"", "What is the name of your first pet?", "What is your favorite color?", "In what city were you born?", "What was your father middle name?", "What was your childhood nickname?", "What is your oldest sibling name?"})
        Me.cmbSecretQuestion.Location = New System.Drawing.Point(123, 54)
        Me.cmbSecretQuestion.MaxLength = 40
        Me.cmbSecretQuestion.Name = "cmbSecretQuestion"
        Me.cmbSecretQuestion.Size = New System.Drawing.Size(217, 21)
        Me.cmbSecretQuestion.TabIndex = 17
        '
        'chckboxSecretAnswer
        '
        Me.chckboxSecretAnswer.AutoSize = True
        Me.chckboxSecretAnswer.BackColor = System.Drawing.Color.Transparent
        Me.chckboxSecretAnswer.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chckboxSecretAnswer.ForeColor = System.Drawing.Color.Black
        Me.chckboxSecretAnswer.Location = New System.Drawing.Point(123, 126)
        Me.chckboxSecretAnswer.Name = "chckboxSecretAnswer"
        Me.chckboxSecretAnswer.Size = New System.Drawing.Size(125, 17)
        Me.chckboxSecretAnswer.TabIndex = 12
        Me.chckboxSecretAnswer.TabStop = False
        Me.chckboxSecretAnswer.Text = "Show Secret Answer"
        Me.chckboxSecretAnswer.UseVisualStyleBackColor = False
        '
        'txtUsername
        '
        Me.txtUsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUsername.Location = New System.Drawing.Point(123, 21)
        Me.txtUsername.MaxLength = 12
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(217, 20)
        Me.txtUsername.TabIndex = 16
        '
        'lblSecretAnswer
        '
        Me.lblSecretAnswer.AutoSize = True
        Me.lblSecretAnswer.BackColor = System.Drawing.Color.Transparent
        Me.lblSecretAnswer.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblSecretAnswer.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSecretAnswer.ForeColor = System.Drawing.Color.Black
        Me.lblSecretAnswer.Location = New System.Drawing.Point(41, 94)
        Me.lblSecretAnswer.Name = "lblSecretAnswer"
        Me.lblSecretAnswer.Size = New System.Drawing.Size(76, 13)
        Me.lblSecretAnswer.TabIndex = 13
        Me.lblSecretAnswer.Text = "Secret Answer"
        '
        'lblSecretQuestion
        '
        Me.lblSecretQuestion.AutoSize = True
        Me.lblSecretQuestion.BackColor = System.Drawing.Color.Transparent
        Me.lblSecretQuestion.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblSecretQuestion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSecretQuestion.ForeColor = System.Drawing.Color.Black
        Me.lblSecretQuestion.Location = New System.Drawing.Point(34, 57)
        Me.lblSecretQuestion.Name = "lblSecretQuestion"
        Me.lblSecretQuestion.Size = New System.Drawing.Size(83, 13)
        Me.lblSecretQuestion.TabIndex = 14
        Me.lblSecretQuestion.Text = "Secret Question"
        '
        'lblUsername
        '
        Me.lblUsername.AutoSize = True
        Me.lblUsername.BackColor = System.Drawing.Color.Transparent
        Me.lblUsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUsername.ForeColor = System.Drawing.Color.Black
        Me.lblUsername.Location = New System.Drawing.Point(62, 24)
        Me.lblUsername.Name = "lblUsername"
        Me.lblUsername.Size = New System.Drawing.Size(55, 13)
        Me.lblUsername.TabIndex = 15
        Me.lblUsername.Text = "Username"
        '
        'btnBack
        '
        Me.btnBack.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnBack.Location = New System.Drawing.Point(223, 153)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(94, 23)
        Me.btnBack.TabIndex = 20
        Me.btnBack.Text = "&Back"
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(120, 153)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(94, 23)
        Me.btnSubmit.TabIndex = 19
        Me.btnSubmit.Text = "&Submit"
        '
        'frmForgotPassword
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(401, 192)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.txtSecretAnswer)
        Me.Controls.Add(Me.cmbSecretQuestion)
        Me.Controls.Add(Me.chckboxSecretAnswer)
        Me.Controls.Add(Me.txtUsername)
        Me.Controls.Add(Me.lblSecretAnswer)
        Me.Controls.Add(Me.lblSecretQuestion)
        Me.Controls.Add(Me.lblUsername)
        Me.Name = "frmForgotPassword"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Forgot Password"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtSecretAnswer As System.Windows.Forms.TextBox
    Friend WithEvents cmbSecretQuestion As System.Windows.Forms.ComboBox
    Friend WithEvents chckboxSecretAnswer As System.Windows.Forms.CheckBox
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    Friend WithEvents lblSecretAnswer As System.Windows.Forms.Label
    Friend WithEvents lblSecretQuestion As System.Windows.Forms.Label
    Friend WithEvents lblUsername As System.Windows.Forms.Label
    Friend WithEvents btnBack As System.Windows.Forms.Button
    Friend WithEvents btnSubmit As System.Windows.Forms.Button
End Class
